

Emulator Build Procedure


Before building the Oberon emulator, be sure to execute the
script "install-lib.sh" which is stored in this folder.

This script installs the SDL library which is required to 
build the emulator.