#ifndef PCLINK_H
#define PCLINK_H

#include "risc-io.h"

extern const struct RISC_Serial pclink;

#endif  // PCLINK_H
