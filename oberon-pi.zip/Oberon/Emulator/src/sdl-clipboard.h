#ifndef SDL_CLIPBOARD_H
#define SDL_CLIPBOARD_H

#include "risc-io.h"

extern const struct RISC_Clipboard sdl_clipboard;

#endif  // SDL_CLIPBOARD_H
