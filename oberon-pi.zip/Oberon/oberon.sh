#!/bin/bash
cd ~/Oberon
./Emulator/risc --zoom 1.6 --size 1070x600 --mem 8 DiskImage/Oberon-System.dsk
/bin/read -n 1
